create definer = root@localhost trigger no_update
    before update
    on regioni
    for each row
    SIGNAL SQLSTATE VALUE '99999'
SET MESSAGE_TEXT = 'You cannot UPDATE rows to this table.';

