create definer = root@localhost trigger no_delete
    before delete
    on regioni
    for each row
    SIGNAL SQLSTATE VALUE '99999'
SET MESSAGE_TEXT = 'You cannot DELETE rows to this table.';

