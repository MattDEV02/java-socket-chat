create definer = root@localhost trigger no_insert
    before insert
    on regioni
    for each row
    SIGNAL SQLSTATE VALUE '99999'
SET MESSAGE_TEXT = 'You cannot INSERT rows to this table.';

